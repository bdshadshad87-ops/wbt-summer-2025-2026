(function () {
    'use strict';

    var POLL_INTERVAL_MS = 15000;

    function initNotifications() {
        var bell     = document.getElementById('notifBell');
        var dropdown = document.getElementById('notifDropdown');
        var countEl  = document.getElementById('notifCount');
        var listEl   = document.getElementById('notifList');

        if (!bell || !dropdown) {
            return;
        }

        function renderItems(items) {
            listEl.innerHTML = '';

            if (!items.length) {
                var empty = document.createElement('p');
                empty.className = 'notif-empty';
                empty.textContent = 'All products are sufficiently stocked.';
                listEl.appendChild(empty);
                return;
            }

            items.forEach(function (item) {
                var row = document.createElement('div');
                row.className = 'notif-item';

                var name = document.createElement('strong');
                name.textContent = item.name;

                var detail = document.createElement('span');
                detail.textContent = 'Qty: ' + item.quantity + ' (threshold ' + item.threshold + ')';

                row.appendChild(name);
                row.appendChild(detail);
                listEl.appendChild(row);
            });
        }

        function refreshNotifications() {
            fetch('ajax_low_stock.php', { credentials: 'same-origin' })
                .then(function (res) {
                    if (!res.ok) {
                        throw new Error('Request failed: ' + res.status);
                    }
                    return res.json();
                })
                .then(function (data) {
                    var count = data.count || 0;

                    if (count > 0) {
                        countEl.hidden = false;
                        countEl.textContent = count > 99 ? '99+' : String(count);
                    } else {
                        countEl.hidden = true;
                    }

                    renderItems(data.items || []);
                })
                .catch(function () {
                    listEl.innerHTML = '<p class="notif-empty">Could not load notifications.</p>';
                });
        }

        bell.addEventListener('click', function (e) {
            e.stopPropagation();
            dropdown.hidden = !dropdown.hidden;
            if (!dropdown.hidden) {
                refreshNotifications();
            }
        });

        document.addEventListener('click', function (e) {
            if (!dropdown.hidden && !dropdown.contains(e.target) && e.target !== bell) {
                dropdown.hidden = true;
            }
        });

        refreshNotifications();
        window.setInterval(refreshNotifications, POLL_INTERVAL_MS);
    }

    function showError(field, message) {
        clearError(field);
        var msg = document.createElement('small');
        msg.className = 'field-error js-error';
        msg.textContent = message;
        field.parentNode.appendChild(msg);
        field.classList.add('input-invalid');
    }

    function clearError(field) {
        field.classList.remove('input-invalid');
        var existing = field.parentNode.querySelector('.js-error');
        if (existing) {
            existing.parentNode.removeChild(existing);
        }
    }

    function validateProductForm() {
        var form = document.querySelector('.entity-form');

        if (!form) {
            return;
        }

        form.addEventListener('submit', function (e) {
            var ok = true;

            var name = form.querySelector('[name="name"]');
            if (name) {
                clearError(name);
                if (!name.value.trim()) {
                    showError(name, 'Product name is required.');
                    ok = false;
                } else if (name.value.trim().length > 150) {
                    showError(name, 'Product name must be 150 characters or fewer.');
                    ok = false;
                }
            }

            var price = form.querySelector('[name="price"]');
            if (price) {
                clearError(price);
                if (price.value === '' || isNaN(parseFloat(price.value)) || parseFloat(price.value) <= 0) {
                    showError(price, 'Enter a selling price greater than 0.');
                    ok = false;
                }
            }

            var wholesale = form.querySelector('[name="wholesale_price"]');
            if (wholesale && wholesale.value !== '') {
                clearError(wholesale);
                if (isNaN(parseFloat(wholesale.value)) || parseFloat(wholesale.value) < 0) {
                    showError(wholesale, 'Wholesale price must be 0 or more.');
                    ok = false;
                } else if (price && price.value !== '' && parseFloat(wholesale.value) > parseFloat(price.value)) {
                    showError(wholesale, 'Wholesale price cannot exceed the selling price.');
                    ok = false;
                }
            }

            ['quantity', 'threshold'].forEach(function (fieldName) {
                var field = form.querySelector('[name="' + fieldName + '"]');
                if (!field) {
                    return;
                }
                clearError(field);
                if (field.value === '' || !/^\d+$/.test(field.value)) {
                    showError(field, 'Enter a whole number of 0 or more.');
                    ok = false;
                }
            });

            if (!ok) {
                e.preventDefault();
            }
        });
    }

    function validateDiscountDates() {
        var forms = document.querySelectorAll('form[id^="discForm"]');

        Array.prototype.forEach.call(forms, function (form) {
            form.addEventListener('submit', function (e) {
                var percent = document.querySelector('[form="' + form.id + '"][name="discount_percent"]');
                var start   = document.querySelector('[form="' + form.id + '"][name="start_date"]');
                var end     = document.querySelector('[form="' + form.id + '"][name="end_date"]');

                if (percent && (percent.value === '' || parseFloat(percent.value) < 0 || parseFloat(percent.value) > 90)) {
                    window.alert('Discount must be between 0 and 90 percent.');
                    e.preventDefault();
                    return;
                }

                if (!start || !end || !start.value || !end.value) {
                    window.alert('Both start and end dates are required.');
                    e.preventDefault();
                    return;
                }

                if (end.value < start.value) {
                    window.alert('End date cannot be earlier than the start date.');
                    e.preventDefault();
                }
            });
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        initNotifications();
        validateProductForm();
        validateDiscountDates();
    });
})();
