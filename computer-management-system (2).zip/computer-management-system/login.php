<?php
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'httponly' => true,
    'samesite' => 'Lax',
    'secure'   => !empty($_SERVER['HTTPS']),
]);
session_start();
require_once __DIR__ . '/config/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Please enter both email and password.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $stmt = db_query($conn, 'SELECT * FROM users WHERE email = ? LIMIT 1', 's', [$email]);
        $user = db_fetch_one($stmt);

        if ($user && password_verify($password, $user['password']) && $user['status'] === 'active') {
            session_regenerate_id(true);
            $_SESSION['user_id']       = $user['user_id'];
            $_SESSION['role']          = $user['role'];
            $_SESSION['name']          = $user['name'];
            $_SESSION['last_activity'] = time();

            if ($user['role'] === 'seller') {
                header('Location: seller/dashboard.php');
            } else {
                header('Location: login.php?msg=' . urlencode('Logged in as ' . $user['role'] . '. That dashboard is not part of this module.'));
            }
            exit;
        }

        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | Computer Shop Management System</title>
<link rel="stylesheet" href="css/seller.css">
</head>
<body class="login-body">
<div class="login-box">
    <h1>Computer Shop Management System</h1>
    <p class="login-sub">Sign in (seller test account: <strong>seller@shop.test</strong> / <strong>password123</strong>)</p>

    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if (!empty($_GET['msg'])): ?><div class="alert alert-success"><?= htmlspecialchars($_GET['msg']) ?></div><?php endif; ?>

    <form method="post" action="login.php" class="login-form" novalidate>
        <label>Email
            <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? 'seller@shop.test') ?>">
        </label>
        <label>Password
            <input type="password" name="password" required minlength="6">
        </label>
        <button type="submit" class="btn btn-block">Login</button>
    </form>
</div>
</body>
</html>
