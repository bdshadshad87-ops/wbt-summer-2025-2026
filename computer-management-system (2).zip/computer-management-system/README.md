# Computer Shop Management System — Seller Module

This is the **Seller** part of the system (Customer / Seller / Vendor / Admin
are separate modules per the project plan). Plain PHP + MySQL, no framework.

## Features implemented

- **Dashboard** (`seller/dashboard.php`) — products listed, low-stock count,
  pending/processing orders, delivered revenue, recent orders.
- **Product management — full CRUD**
  - `seller/products.php` — list every product with search and category
    filter, plus Edit and Delete actions.
  - `seller/product_form.php` — one form for both Add and Edit. Creates the
    product and its stock row inside a single transaction.
  - Delete removes the product, its stock row and its discount together.
    A product that already appears in `order_items` cannot be deleted,
    because the foreign key cascades and would destroy order history.
- **Stock management** (`seller/stock.php`) — view/update quantity and
  low-stock threshold per product; low-stock rows are highlighted.
- **Live stock notification** (`seller/ajax_low_stock.php` + the bell icon in
  the header, driven by `js/seller.js`) — polls every 15s and shows a badge
  and dropdown of low-stock products, no page reload needed.
- **Discounts** (`seller/discount.php`) — set a discount % and date range per
  product, or deactivate an existing discount.
- **Orders** (`seller/orders.php`) — every order containing one of the
  seller's products, filterable by status, with the seller's own subtotal.
- **Order status update** (`seller/update_order.php`) — pending → processing
  → shipped → delivered → cancelled.
- **Sales summary** (`seller/sales_summary.php`) — revenue, units sold and
  order count for delivered orders in a date range, top products by revenue,
  and an order-status breakdown.
- **Logout** (`seller/logout.php`).

## Security and validation

Session handling (`includes/auth.php`):

- Every seller page checks `$_SESSION['role'] === 'seller'`.
- Session cookie is set `HttpOnly`, `SameSite=Lax`, and `Secure` over HTTPS.
- `session_regenerate_id(true)` on login prevents session fixation.
- 30 minute idle timeout; logout clears the session array, expires the
  browser cookie and destroys the session.

Every write action checks a CSRF token and confirms the product or order
actually belongs to the logged-in seller.

Server-side validation covers: required fields, string length limits matching
the column widths, numeric and range checks on prices, whole-number checks on
quantities, duplicate product names per seller, a 0–90 range on discounts, and
real calendar dates via `valid_date()` (regex plus `checkdate()`), so values
like `2026-02-31` are rejected before reaching MySQL. `js/seller.js` repeats
the product-form and discount-date checks in the browser for faster feedback.

All queries use PDO prepared statements with `ATTR_EMULATE_PREPARES => false`,
and every echoed value passes through `htmlspecialchars()`.

## Setup

1. Create the database and import the schema (also creates seed/test data):
   ```
   mysql -u root -p -e "CREATE DATABASE computer_management"
   mysql -u root -p computer_management < database/computer_management.sql
   ```
2. `config/database.php` defaults to user `root` with an empty password,
   which matches a stock XAMPP install. Edit those two lines if your MySQL
   user differs, or set the `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`
   environment variables instead.
3. Serve the project root (not the `seller/` folder) — e.g.
   ```
   php -S localhost:8000
   ```
   or point an Apache/Nginx vhost at this folder. On XAMPP, drop the folder
   into `htdocs` and open `http://localhost/computer-management-system/`.
4. Open `login.php` and sign in with the seeded test account:
   - Email: `seller@shop.test`
   - Password: `password123`

Other seeded accounts (`vendor@shop.test`, `customer@shop.test`,
`admin@shop.test`, same password) exist only so the shared `users` table looks
realistic — they don't have dashboards in this module.

`login.php` is a **minimal stand-in login page**; full auth/registration is
shared across all four roles and isn't part of this module. Swap it for the
team's real login page later — it only needs to set `$_SESSION['user_id']`,
`$_SESSION['role']` and `$_SESSION['name']` the same way this one does.

## Testing performed

Exercised end-to-end against PHP 8.3 with the built-in server and a live
MariaDB 10.11 instance:

- Create, update and delete a product, verified directly in the database.
- Delete correctly blocked for a product referenced by `order_items`.
- Invalid input rejected: empty name, negative price, wholesale price above
  selling price, non-numeric quantity, duplicate product name, discount of
  150%, end date before start date, `2026-02-31`, and a bogus order status.
- CSRF: POSTs without a token are rejected and write nothing.
- Ownership: a second seller account was blocked from editing, deleting,
  restocking or discounting another seller's product, and from updating an
  order it has no items in.
- Unauthenticated access to every seller page redirects to `login.php`, and
  protected pages stay blocked after logout.
- `php -l` passes on every PHP file; `node --check` passes on `js/seller.js`.

Note: `text_length()` in `includes/auth.php` falls back to `strlen()` when the
`mbstring` extension is unavailable, so the module runs on stripped-down PHP
builds as well as XAMPP.
