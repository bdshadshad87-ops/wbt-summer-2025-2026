<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

$totalProducts = (int) db_fetch_column(db_query(
    $conn,
    'SELECT COUNT(*) FROM products WHERE seller_id = ?',
    'i',
    [$sellerId]
));

$lowStock = (int) db_fetch_column(db_query(
    $conn,
    'SELECT COUNT(*) FROM stock s
     JOIN products p ON p.product_id = s.product_id
     WHERE p.seller_id = ? AND s.quantity <= s.low_stock_threshold',
    'i',
    [$sellerId]
));

$pendingOrders = (int) db_fetch_column(db_query(
    $conn,
    "SELECT COUNT(DISTINCT o.order_id) FROM orders o
     JOIN order_items oi ON oi.order_id = o.order_id
     WHERE oi.seller_id = ? AND o.status IN ('pending','processing')",
    'i',
    [$sellerId]
));

$totalRevenue = (float) db_fetch_column(db_query(
    $conn,
    "SELECT COALESCE(SUM(oi.subtotal), 0) FROM order_items oi
     JOIN orders o ON o.order_id = oi.order_id
     WHERE oi.seller_id = ? AND o.status = 'delivered'",
    'i',
    [$sellerId]
));

$recentOrders = db_fetch_all(db_query(
    $conn,
    "SELECT o.order_id, o.order_date, o.status,
            SUM(oi.subtotal) AS seller_subtotal,
            u.name AS customer_name
     FROM orders o
     JOIN order_items oi ON oi.order_id = o.order_id
     JOIN users u ON u.user_id = o.customer_id
     WHERE oi.seller_id = ?
     GROUP BY o.order_id, o.order_date, o.status, u.name
     ORDER BY o.order_date DESC
     LIMIT 5",
    'i',
    [$sellerId]
));

$pageTitle = 'Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<?php flash_render(); ?>

<section class="cards-grid">
    <div class="stat-card">
        <div class="stat-icon">&#128421;</div>
        <div>
            <div class="stat-value"><?= $totalProducts ?></div>
            <div class="stat-label">Products Listed</div>
        </div>
    </div>
    <div class="stat-card <?= $lowStock > 0 ? 'stat-card-warning' : '' ?>">
        <div class="stat-icon">&#9888;</div>
        <div>
            <div class="stat-value"><?= $lowStock ?></div>
            <div class="stat-label">Low Stock Items</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">&#128203;</div>
        <div>
            <div class="stat-value"><?= $pendingOrders ?></div>
            <div class="stat-label">Pending / Processing Orders</div>
        </div>
    </div>
    <div class="stat-card stat-card-success">
        <div class="stat-icon">&#128176;</div>
        <div>
            <div class="stat-value">&#2547;<?= number_format($totalRevenue, 2) ?></div>
            <div class="stat-label">Revenue (Delivered)</div>
        </div>
    </div>
</section>

<section class="panel">
    <div class="panel-header">
        <h2>Recent Orders</h2>
        <a href="orders.php" class="btn btn-sm">View all</a>
    </div>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Order #</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Your Subtotal</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$recentOrders): ?>
                <tr><td colspan="5" class="empty-row">No orders yet.</td></tr>
            <?php else: foreach ($recentOrders as $o): ?>
                <tr>
                    <td>#<?= (int) $o['order_id'] ?></td>
                    <td><?= htmlspecialchars($o['customer_name']) ?></td>
                    <td><?= htmlspecialchars(date('d M Y, H:i', strtotime($o['order_date']))) ?></td>
                    <td>&#2547;<?= number_format((float) $o['seller_subtotal'], 2) ?></td>
                    <td><span class="badge badge-<?= htmlspecialchars($o['status']) ?>"><?= htmlspecialchars(ucfirst($o['status'])) ?></span></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
