<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: orders.php');
    exit;
}

if (!csrf_check()) {
    flash_set('error', 'Invalid form submission. Please try again.');
    header('Location: orders.php');
    exit;
}

$orderId       = (int) ($_POST['order_id'] ?? 0);
$status        = $_POST['status'] ?? '';
$validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];

if ($orderId <= 0 || !in_array($status, $validStatuses, true)) {
    flash_set('error', 'Invalid order or status.');
    header('Location: orders.php');
    exit;
}

$check = db_query($conn, 'SELECT 1 FROM order_items WHERE order_id = ? AND seller_id = ? LIMIT 1', 'ii', [$orderId, $sellerId]);

if (!db_fetch_one($check)) {
    flash_set('error', 'You do not have permission to update that order.');
    header('Location: orders.php');
    exit;
}

db_query($conn, 'UPDATE orders SET status = ? WHERE order_id = ?', 'si', [$status, $orderId]);

flash_set('success', "Order #{$orderId} status updated to \"" . ucfirst($status) . '".');
header('Location: orders.php');
exit;
