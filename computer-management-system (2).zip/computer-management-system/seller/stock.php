<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_stock') {
    if (!csrf_check()) {
        flash_set('error', 'Invalid form submission. Please try again.');
        header('Location: stock.php');
        exit;
    }

    $productId    = (int) ($_POST['product_id'] ?? 0);
    $rawQuantity  = trim($_POST['quantity'] ?? '');
    $rawThreshold = trim($_POST['threshold'] ?? '');

    if ($productId <= 0 || !ctype_digit($rawQuantity) || !ctype_digit($rawThreshold)) {
        flash_set('error', 'Quantity and threshold must be whole numbers of 0 or more.');
        header('Location: stock.php');
        exit;
    }

    $quantity  = (int) $rawQuantity;
    $threshold = (int) $rawThreshold;

    if ($quantity > 1000000 || $threshold > 1000000) {
        flash_set('error', 'Quantity and threshold cannot exceed 1,000,000.');
        header('Location: stock.php');
        exit;
    }

    $own = db_query($conn, 'SELECT product_id FROM products WHERE product_id = ? AND seller_id = ?', 'ii', [$productId, $sellerId]);

    if (!db_fetch_one($own)) {
        flash_set('error', 'You do not have permission to update that product.');
        header('Location: stock.php');
        exit;
    }

    db_query(
        $conn,
        'INSERT INTO stock (product_id, quantity, low_stock_threshold)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE quantity = VALUES(quantity),
                                 low_stock_threshold = VALUES(low_stock_threshold)',
        'iii',
        [$productId, $quantity, $threshold]
    );

    flash_set('success', 'Stock updated successfully.');
    header('Location: stock.php');
    exit;
}

$products = db_fetch_all(db_query(
    $conn,
    'SELECT p.product_id, p.name, p.category,
            COALESCE(s.quantity, 0) AS quantity,
            COALESCE(s.low_stock_threshold, 5) AS low_stock_threshold
     FROM products p
     LEFT JOIN stock s ON s.product_id = p.product_id
     WHERE p.seller_id = ?
     ORDER BY (COALESCE(s.quantity, 0) <= COALESCE(s.low_stock_threshold, 5)) DESC, p.name ASC',
    'i',
    [$sellerId]
));

$pageTitle = 'Stock Management';
require_once __DIR__ . '/../includes/header.php';
?>

<?php flash_render(); ?>

<section class="panel">
    <div class="panel-header">
        <h2>Your Product Stock</h2>
        <span class="panel-subtitle">Low-stock rows are highlighted; the bell icon above updates live.</span>
    </div>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Category</th>
                    <th>Quantity</th>
                    <th>Low-stock threshold</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$products): ?>
                <tr><td colspan="6" class="empty-row">No products found.</td></tr>
            <?php else: foreach ($products as $p):
                $low    = $p['quantity'] <= $p['low_stock_threshold'];
                $formId = 'stockForm' . (int) $p['product_id'];
            ?>
                <tr class="<?= $low ? 'row-low-stock' : '' ?>">
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td><?= htmlspecialchars($p['category'] ?? '-') ?></td>
                    <td><input type="number" name="quantity" min="0" step="1" value="<?= (int) $p['quantity'] ?>" class="qty-input" form="<?= $formId ?>"></td>
                    <td><input type="number" name="threshold" min="0" step="1" value="<?= (int) $p['low_stock_threshold'] ?>" class="qty-input" form="<?= $formId ?>"></td>
                    <td>
                        <?php if ($low): ?>
                            <span class="badge badge-warning">Low Stock</span>
                        <?php else: ?>
                            <span class="badge badge-ok">In Stock</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form id="<?= $formId ?>" method="post" action="stock.php" class="inline-stock-form">
                            <input type="hidden" name="action" value="update_stock">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
                            <input type="hidden" name="product_id" value="<?= (int) $p['product_id'] ?>">
                        </form>
                        <button type="submit" form="<?= $formId ?>" class="btn btn-sm">Update</button>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
