<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

$productId = (int) ($_GET['id'] ?? 0);
$isEdit    = $productId > 0;
$errors    = [];

$form = [
    'name'            => '',
    'category'        => '',
    'brand'           => '',
    'description'     => '',
    'price'           => '',
    'wholesale_price' => '',
    'image'           => '',
    'quantity'        => '0',
    'threshold'       => '5',
];

if ($isEdit) {
    $existing = db_fetch_one(db_query(
        $conn,
        'SELECT p.product_id, p.name, p.category, p.brand, p.description, p.price,
                p.wholesale_price, p.image,
                COALESCE(s.quantity, 0) AS quantity,
                COALESCE(s.low_stock_threshold, 5) AS low_stock_threshold
         FROM products p
         LEFT JOIN stock s ON s.product_id = p.product_id
         WHERE p.product_id = ? AND p.seller_id = ?',
        'ii',
        [$productId, $sellerId]
    ));

    if (!$existing) {
        flash_set('error', 'Product not found or you do not have permission to edit it.');
        header('Location: products.php');
        exit;
    }

    $form = [
        'name'            => $existing['name'],
        'category'        => $existing['category'] ?? '',
        'brand'           => $existing['brand'] ?? '',
        'description'     => $existing['description'] ?? '',
        'price'           => $existing['price'],
        'wholesale_price' => $existing['wholesale_price'] ?? '',
        'image'           => $existing['image'] ?? '',
        'quantity'        => $existing['quantity'],
        'threshold'       => $existing['low_stock_threshold'],
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        flash_set('error', 'Invalid form submission. Please try again.');
        header('Location: products.php');
        exit;
    }

    $productId = (int) ($_POST['product_id'] ?? 0);
    $isEdit    = $productId > 0;

    $form = [
        'name'            => trim($_POST['name'] ?? ''),
        'category'        => trim($_POST['category'] ?? ''),
        'brand'           => trim($_POST['brand'] ?? ''),
        'description'     => trim($_POST['description'] ?? ''),
        'price'           => trim($_POST['price'] ?? ''),
        'wholesale_price' => trim($_POST['wholesale_price'] ?? ''),
        'image'           => trim($_POST['image'] ?? ''),
        'quantity'        => trim($_POST['quantity'] ?? '0'),
        'threshold'       => trim($_POST['threshold'] ?? '5'),
    ];

    if ($form['name'] === '') {
        $errors['name'] = 'Product name is required.';
    } elseif (text_length($form['name']) > 150) {
        $errors['name'] = 'Product name must be 150 characters or fewer.';
    }

    if (text_length($form['category']) > 80) {
        $errors['category'] = 'Category must be 80 characters or fewer.';
    }

    if (text_length($form['brand']) > 80) {
        $errors['brand'] = 'Brand must be 80 characters or fewer.';
    }

    if (text_length($form['image']) > 255) {
        $errors['image'] = 'Image path must be 255 characters or fewer.';
    }

    if ($form['price'] === '' || !is_numeric($form['price'])) {
        $errors['price'] = 'Selling price is required and must be a number.';
    } elseif ((float) $form['price'] <= 0 || (float) $form['price'] > 99999999.99) {
        $errors['price'] = 'Selling price must be between 0.01 and 99,999,999.99.';
    }

    if ($form['wholesale_price'] !== '') {
        if (!is_numeric($form['wholesale_price'])) {
            $errors['wholesale_price'] = 'Wholesale price must be a number.';
        } elseif ((float) $form['wholesale_price'] < 0 || (float) $form['wholesale_price'] > 99999999.99) {
            $errors['wholesale_price'] = 'Wholesale price must be between 0 and 99,999,999.99.';
        } elseif (empty($errors['price']) && (float) $form['wholesale_price'] > (float) $form['price']) {
            $errors['wholesale_price'] = 'Wholesale price cannot be higher than the selling price.';
        }
    }

    if (!ctype_digit($form['quantity'])) {
        $errors['quantity'] = 'Quantity must be a whole number of 0 or more.';
    } elseif ((int) $form['quantity'] > 1000000) {
        $errors['quantity'] = 'Quantity cannot exceed 1,000,000.';
    }

    if (!ctype_digit($form['threshold'])) {
        $errors['threshold'] = 'Low-stock threshold must be a whole number of 0 or more.';
    } elseif ((int) $form['threshold'] > 1000000) {
        $errors['threshold'] = 'Low-stock threshold cannot exceed 1,000,000.';
    }

    if ($isEdit) {
        $own = db_query($conn, 'SELECT product_id FROM products WHERE product_id = ? AND seller_id = ?', 'ii', [$productId, $sellerId]);
        if (!db_fetch_one($own)) {
            flash_set('error', 'You do not have permission to edit that product.');
            header('Location: products.php');
            exit;
        }
    }

    $dupSql = 'SELECT product_id FROM products WHERE seller_id = ? AND name = ?';
    $dupTypes = 'is';
    $dupParams = [$sellerId, $form['name']];
    if ($isEdit) {
        $dupSql .= ' AND product_id <> ?';
        $dupTypes .= 'i';
        $dupParams[] = $productId;
    }
    $dup = db_query($conn, $dupSql, $dupTypes, $dupParams);
    if (db_fetch_one($dup)) {
        $errors['name'] = 'You already have a product with this name.';
    }

    if (!$errors) {
        $price     = (float) $form['price'];
        $wholesale = $form['wholesale_price'] === '' ? null : (float) $form['wholesale_price'];
        $quantity  = (int) $form['quantity'];
        $threshold = (int) $form['threshold'];

        $conn->begin_transaction();
        try {
            if ($isEdit) {
                db_query(
                    $conn,
                    'UPDATE products
                     SET name = ?, category = ?, brand = ?, description = ?, price = ?,
                         wholesale_price = ?, image = ?
                     WHERE product_id = ? AND seller_id = ?',
                    'ssssddsii',
                    [
                        $form['name'],
                        $form['category'] !== '' ? $form['category'] : null,
                        $form['brand'] !== '' ? $form['brand'] : null,
                        $form['description'] !== '' ? $form['description'] : null,
                        $price,
                        $wholesale,
                        $form['image'] !== '' ? $form['image'] : null,
                        $productId,
                        $sellerId,
                    ]
                );

                db_query(
                    $conn,
                    'INSERT INTO stock (product_id, quantity, low_stock_threshold)
                     VALUES (?, ?, ?)
                     ON DUPLICATE KEY UPDATE quantity = VALUES(quantity),
                                             low_stock_threshold = VALUES(low_stock_threshold)',
                    'iii',
                    [$productId, $quantity, $threshold]
                );

                $message = 'Product updated successfully.';
            } else {
                db_query(
                    $conn,
                    'INSERT INTO products (seller_id, name, category, brand, description, price, wholesale_price, image)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    'isssddds',
                    [
                        $sellerId,
                        $form['name'],
                        $form['category'] !== '' ? $form['category'] : null,
                        $form['brand'] !== '' ? $form['brand'] : null,
                        $form['description'] !== '' ? $form['description'] : null,
                        $price,
                        $wholesale,
                        $form['image'] !== '' ? $form['image'] : null,
                    ]
                );

                $newId = (int) $conn->insert_id;

                db_query(
                    $conn,
                    'INSERT INTO stock (product_id, quantity, low_stock_threshold) VALUES (?, ?, ?)',
                    'iii',
                    [$newId, $quantity, $threshold]
                );

                $message = 'Product added successfully.';
            }

            $conn->commit();
            flash_set('success', $message);
            header('Location: products.php');
            exit;
        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            $errors['general'] = 'Could not save the product. Please try again.';
        }
    }
}

$pageTitle = $isEdit ? 'Edit Product' : 'Add Product';
require_once __DIR__ . '/../includes/header.php';
?>

<?php flash_render(); ?>

<?php if (!empty($errors['general'])): ?>
    <div class="alert alert-error"><?= htmlspecialchars($errors['general']) ?></div>
<?php endif; ?>

<section class="panel">
    <div class="panel-header">
        <h2><?= $isEdit ? 'Edit Product' : 'Add a New Product' ?></h2>
        <a href="products.php" class="btn btn-sm">&#8592; Back to products</a>
    </div>

    <form method="post" action="product_form.php<?= $isEdit ? '?id=' . (int) $productId : '' ?>" class="entity-form" novalidate>
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
        <input type="hidden" name="product_id" value="<?= (int) $productId ?>">

        <div class="form-grid">
            <label class="form-field form-field-wide">
                <span>Product name <em>*</em></span>
                <input type="text" name="name" maxlength="150" required value="<?= htmlspecialchars($form['name']) ?>">
                <?php if (!empty($errors['name'])): ?><small class="field-error"><?= htmlspecialchars($errors['name']) ?></small><?php endif; ?>
            </label>

            <label class="form-field">
                <span>Category</span>
                <input type="text" name="category" maxlength="80" value="<?= htmlspecialchars($form['category']) ?>" placeholder="CPU, GPU, RAM...">
                <?php if (!empty($errors['category'])): ?><small class="field-error"><?= htmlspecialchars($errors['category']) ?></small><?php endif; ?>
            </label>

            <label class="form-field">
                <span>Brand</span>
                <input type="text" name="brand" maxlength="80" value="<?= htmlspecialchars($form['brand']) ?>">
                <?php if (!empty($errors['brand'])): ?><small class="field-error"><?= htmlspecialchars($errors['brand']) ?></small><?php endif; ?>
            </label>

            <label class="form-field">
                <span>Selling price (&#2547;) <em>*</em></span>
                <input type="number" name="price" step="0.01" min="0.01" required value="<?= htmlspecialchars($form['price']) ?>">
                <?php if (!empty($errors['price'])): ?><small class="field-error"><?= htmlspecialchars($errors['price']) ?></small><?php endif; ?>
            </label>

            <label class="form-field">
                <span>Wholesale price (&#2547;)</span>
                <input type="number" name="wholesale_price" step="0.01" min="0" value="<?= htmlspecialchars($form['wholesale_price']) ?>">
                <?php if (!empty($errors['wholesale_price'])): ?><small class="field-error"><?= htmlspecialchars($errors['wholesale_price']) ?></small><?php endif; ?>
            </label>

            <label class="form-field">
                <span>Opening quantity</span>
                <input type="number" name="quantity" min="0" step="1" value="<?= htmlspecialchars($form['quantity']) ?>">
                <?php if (!empty($errors['quantity'])): ?><small class="field-error"><?= htmlspecialchars($errors['quantity']) ?></small><?php endif; ?>
            </label>

            <label class="form-field">
                <span>Low-stock threshold</span>
                <input type="number" name="threshold" min="0" step="1" value="<?= htmlspecialchars($form['threshold']) ?>">
                <?php if (!empty($errors['threshold'])): ?><small class="field-error"><?= htmlspecialchars($errors['threshold']) ?></small><?php endif; ?>
            </label>

            <label class="form-field form-field-wide">
                <span>Image path</span>
                <input type="text" name="image" maxlength="255" value="<?= htmlspecialchars($form['image']) ?>" placeholder="images/product.jpg">
                <?php if (!empty($errors['image'])): ?><small class="field-error"><?= htmlspecialchars($errors['image']) ?></small><?php endif; ?>
            </label>

            <label class="form-field form-field-wide">
                <span>Description</span>
                <textarea name="description" rows="4"><?= htmlspecialchars($form['description']) ?></textarea>
            </label>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn"><?= $isEdit ? 'Save Changes' : 'Add Product' ?></button>
            <a href="products.php" class="btn btn-sm btn-muted">Cancel</a>
        </div>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
