<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

$statusFilter  = $_GET['status'] ?? '';
$validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];

$sql = "SELECT o.order_id, o.order_date, o.status, o.delivery_address, u.name AS customer_name,
               SUM(oi.subtotal) AS seller_subtotal
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.order_id
        JOIN users u ON u.user_id = o.customer_id
        WHERE oi.seller_id = ?";
$types  = 'i';
$params = [$sellerId];

if (in_array($statusFilter, $validStatuses, true)) {
    $sql .= ' AND o.status = ?';
    $types .= 's';
    $params[] = $statusFilter;
} else {
    $statusFilter = '';
}

$sql .= ' GROUP BY o.order_id, o.order_date, o.status, o.delivery_address, u.name
          ORDER BY o.order_date DESC';

$orders = db_fetch_all(db_query($conn, $sql, $types, $params));

$pageTitle = 'Orders';
require_once __DIR__ . '/../includes/header.php';
?>

<?php flash_render(); ?>

<section class="panel">
    <div class="panel-header">
        <h2>Orders Containing Your Products</h2>
        <form method="get" action="orders.php" class="filter-form">
            <select name="status" onchange="this.form.submit()">
                <option value="">All statuses</option>
                <?php foreach ($validStatuses as $s): ?>
                    <option value="<?= $s ?>" <?= $statusFilter === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <?php if (!$orders): ?>
        <p class="empty-row">No orders found<?= $statusFilter ? ' for status "' . htmlspecialchars($statusFilter) . '"' : '' ?>.</p>
    <?php else: foreach ($orders as $o):
        $items = db_fetch_all(db_query(
            $conn,
            'SELECT oi.order_id, p.name, oi.quantity, oi.unit_price, oi.subtotal
             FROM order_items oi
             JOIN products p ON p.product_id = oi.product_id
             WHERE oi.seller_id = ? AND oi.order_id = ?',
            'ii',
            [$sellerId, $o['order_id']]
        ));
    ?>
        <div class="order-card">
            <div class="order-card-top">
                <div>
                    <strong>Order #<?= (int) $o['order_id'] ?></strong>
                    &mdash; <?= htmlspecialchars($o['customer_name']) ?>
                    <div class="order-meta"><?= htmlspecialchars(date('d M Y, H:i', strtotime($o['order_date']))) ?> &middot; <?= htmlspecialchars($o['delivery_address'] ?? '-') ?></div>
                </div>
                <span class="badge badge-<?= htmlspecialchars($o['status']) ?>"><?= htmlspecialchars(ucfirst($o['status'])) ?></span>
            </div>

            <table class="data-table data-table-compact">
                <thead>
                    <tr><th>Product</th><th>Qty</th><th>Unit Price</th><th>Subtotal</th></tr>
                </thead>
                <tbody>
                <?php foreach ($items as $it): ?>
                    <tr>
                        <td><?= htmlspecialchars($it['name']) ?></td>
                        <td><?= (int) $it['quantity'] ?></td>
                        <td>&#2547;<?= number_format((float) $it['unit_price'], 2) ?></td>
                        <td>&#2547;<?= number_format((float) $it['subtotal'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" class="text-right">Your total for this order</td>
                        <td><strong>&#2547;<?= number_format((float) $o['seller_subtotal'], 2) ?></strong></td>
                    </tr>
                </tfoot>
            </table>

            <form method="post" action="update_order.php" class="order-status-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
                <input type="hidden" name="order_id" value="<?= (int) $o['order_id'] ?>">
                <label>
                    Update status:
                    <select name="status">
                        <?php foreach ($validStatuses as $s): ?>
                            <option value="<?= $s ?>" <?= $o['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <button type="submit" class="btn btn-sm">Update Status</button>
            </form>
        </div>
    <?php endforeach; endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
