<?php
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

$items = db_fetch_all(db_query(
    $conn,
    'SELECT p.product_id, p.name, s.quantity, s.low_stock_threshold
     FROM stock s
     JOIN products p ON p.product_id = s.product_id
     WHERE p.seller_id = ? AND s.quantity <= s.low_stock_threshold
     ORDER BY s.quantity ASC
     LIMIT 20',
    'i',
    [$sellerId]
));

echo json_encode([
    'count' => count($items),
    'items' => array_map(static function ($row) {
        return [
            'product_id' => (int) $row['product_id'],
            'name'       => $row['name'],
            'quantity'   => (int) $row['quantity'],
            'threshold'  => (int) $row['low_stock_threshold'],
        ];
    }, $items),
]);
