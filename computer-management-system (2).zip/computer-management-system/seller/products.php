<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_product') {
    if (!csrf_check()) {
        flash_set('error', 'Invalid form submission. Please try again.');
        header('Location: products.php');
        exit;
    }

    $productId = (int) ($_POST['product_id'] ?? 0);

    if ($productId <= 0) {
        flash_set('error', 'Invalid product.');
        header('Location: products.php');
        exit;
    }

    $own = db_query($conn, 'SELECT name FROM products WHERE product_id = ? AND seller_id = ?', 'ii', [$productId, $sellerId]);
    $product = db_fetch_one($own);

    if (!$product) {
        flash_set('error', 'You do not have permission to delete that product.');
        header('Location: products.php');
        exit;
    }

    $used = db_query($conn, 'SELECT COUNT(*) FROM order_items WHERE product_id = ?', 'i', [$productId]);

    if ((int) db_fetch_column($used) > 0) {
        flash_set('error', 'This product appears in existing orders and cannot be deleted. Set its stock to 0 instead.');
        header('Location: products.php');
        exit;
    }

    $conn->begin_transaction();
    try {
        db_query($conn, 'DELETE FROM discounts WHERE product_id = ?', 'i', [$productId]);
        db_query($conn, 'DELETE FROM stock WHERE product_id = ?', 'i', [$productId]);
        db_query($conn, 'DELETE FROM products WHERE product_id = ? AND seller_id = ?', 'ii', [$productId, $sellerId]);
        $conn->commit();
        flash_set('success', 'Product "' . $product['name'] . '" deleted.');
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        flash_set('error', 'Could not delete the product. Please try again.');
    }

    header('Location: products.php');
    exit;
}

$search   = trim($_GET['q'] ?? '');
$category = trim($_GET['category'] ?? '');

$sql = 'SELECT p.product_id, p.name, p.category, p.brand, p.price, p.wholesale_price,
               COALESCE(s.quantity, 0) AS quantity, COALESCE(s.low_stock_threshold, 0) AS low_stock_threshold
        FROM products p
        LEFT JOIN stock s ON s.product_id = p.product_id
        WHERE p.seller_id = ?';
$types  = 'i';
$params = [$sellerId];

if ($search !== '') {
    $sql .= ' AND (p.name LIKE ? OR p.brand LIKE ?)';
    $types .= 'ss';
    $params[] = '%' . $search . '%';
    $params[] = '%' . $search . '%';
}

if ($category !== '') {
    $sql .= ' AND p.category = ?';
    $types .= 's';
    $params[] = $category;
}

$sql .= ' ORDER BY p.name ASC';

$products = db_fetch_all(db_query($conn, $sql, $types, $params));

$catRows = db_fetch_all(db_query(
    $conn,
    'SELECT DISTINCT category FROM products WHERE seller_id = ? AND category IS NOT NULL ORDER BY category',
    'i',
    [$sellerId]
));
$categories = array_column($catRows, 'category');

$pageTitle = 'Products';
require_once __DIR__ . '/../includes/header.php';
?>

<?php flash_render(); ?>

<section class="panel">
    <div class="panel-header">
        <h2>Your Products</h2>
        <form method="get" action="products.php" class="filter-form">
            <input type="text" name="q" placeholder="Search name or brand" value="<?= htmlspecialchars($search) ?>">
            <select name="category">
                <option value="">All categories</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= htmlspecialchars($c) ?>" <?= $category === $c ? 'selected' : '' ?>><?= htmlspecialchars($c) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-sm">Filter</button>
            <a href="product_form.php" class="btn btn-sm">+ Add Product</a>
        </form>
    </div>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Category</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Wholesale</th>
                    <th>Stock</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$products): ?>
                <tr><td colspan="7" class="empty-row">No products found. Use &ldquo;Add Product&rdquo; to create one.</td></tr>
            <?php else: foreach ($products as $p):
                $low = $p['quantity'] <= $p['low_stock_threshold'];
            ?>
                <tr class="<?= $low ? 'row-low-stock' : '' ?>">
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td><?= htmlspecialchars($p['category'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($p['brand'] ?? '-') ?></td>
                    <td>&#2547;<?= number_format((float) $p['price'], 2) ?></td>
                    <td><?= $p['wholesale_price'] !== null ? '&#2547;' . number_format((float) $p['wholesale_price'], 2) : '-' ?></td>
                    <td>
                        <?= (int) $p['quantity'] ?>
                        <?php if ($low): ?><span class="badge badge-warning">Low</span><?php endif; ?>
                    </td>
                    <td class="action-cell">
                        <a href="product_form.php?id=<?= (int) $p['product_id'] ?>" class="btn btn-sm">Edit</a>
                        <form method="post" action="products.php" class="inline-form"
                              onsubmit="return confirm('Delete this product permanently?');">
                            <input type="hidden" name="action" value="delete_product">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
                            <input type="hidden" name="product_id" value="<?= (int) $p['product_id'] ?>">
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
