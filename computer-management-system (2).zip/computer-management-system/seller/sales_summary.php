<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

$from = trim($_GET['from'] ?? '');
$to   = trim($_GET['to'] ?? '');

if (!valid_date($from)) {
    $from = date('Y-m-d', strtotime('-30 days'));
}

if (!valid_date($to)) {
    $to = date('Y-m-d');
}

if ($to < $from) {
    [$from, $to] = [$to, $from];
}

$totals = db_fetch_one(db_query(
    $conn,
    "SELECT COUNT(DISTINCT o.order_id) AS order_count,
            COALESCE(SUM(oi.quantity), 0) AS units_sold,
            COALESCE(SUM(oi.subtotal), 0) AS revenue
     FROM order_items oi
     JOIN orders o ON o.order_id = oi.order_id
     WHERE oi.seller_id = ? AND o.status = 'delivered'
       AND DATE(o.order_date) BETWEEN ? AND ?",
    'iss',
    [$sellerId, $from, $to]
));

$byProduct = db_fetch_all(db_query(
    $conn,
    "SELECT p.name, SUM(oi.quantity) AS units, SUM(oi.subtotal) AS revenue
     FROM order_items oi
     JOIN orders o ON o.order_id = oi.order_id
     JOIN products p ON p.product_id = oi.product_id
     WHERE oi.seller_id = ? AND o.status = 'delivered'
       AND DATE(o.order_date) BETWEEN ? AND ?
     GROUP BY p.product_id, p.name
     ORDER BY revenue DESC
     LIMIT 10",
    'iss',
    [$sellerId, $from, $to]
));

$maxRevenue = 0;
foreach ($byProduct as $row) {
    $maxRevenue = max($maxRevenue, (float) $row['revenue']);
}

$byStatusRows = db_fetch_all(db_query(
    $conn,
    "SELECT o.status, COUNT(DISTINCT o.order_id) AS cnt
     FROM order_items oi
     JOIN orders o ON o.order_id = oi.order_id
     WHERE oi.seller_id = ? AND DATE(o.order_date) BETWEEN ? AND ?
     GROUP BY o.status",
    'iss',
    [$sellerId, $from, $to]
));
$byStatus = [];
foreach ($byStatusRows as $row) {
    $byStatus[$row['status']] = $row['cnt'];
}

$pageTitle = 'Sales Summary';
require_once __DIR__ . '/../includes/header.php';
?>

<?php flash_render(); ?>

<section class="panel">
    <div class="panel-header">
        <h2>Sales Summary</h2>
        <form method="get" action="sales_summary.php" class="filter-form">
            <label>From <input type="date" name="from" value="<?= htmlspecialchars($from) ?>"></label>
            <label>To <input type="date" name="to" value="<?= htmlspecialchars($to) ?>"></label>
            <button type="submit" class="btn btn-sm">Apply</button>
        </form>
    </div>

    <section class="cards-grid">
        <div class="stat-card">
            <div class="stat-icon">&#128203;</div>
            <div>
                <div class="stat-value"><?= (int) $totals['order_count'] ?></div>
                <div class="stat-label">Delivered Orders</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">&#128230;</div>
            <div>
                <div class="stat-value"><?= (int) $totals['units_sold'] ?></div>
                <div class="stat-label">Units Sold</div>
            </div>
        </div>
        <div class="stat-card stat-card-success">
            <div class="stat-icon">&#128176;</div>
            <div>
                <div class="stat-value">&#2547;<?= number_format((float) $totals['revenue'], 2) ?></div>
                <div class="stat-label">Total Revenue</div>
            </div>
        </div>
    </section>
</section>

<section class="panel">
    <div class="panel-header"><h2>Top Products (by revenue)</h2></div>
    <?php if (!$byProduct): ?>
        <p class="empty-row">No delivered sales in this date range.</p>
    <?php else: ?>
        <div class="bar-chart">
            <?php foreach ($byProduct as $row): $pct = $maxRevenue > 0 ? round(($row['revenue'] / $maxRevenue) * 100) : 0; ?>
                <div class="bar-row">
                    <span class="bar-label"><?= htmlspecialchars($row['name']) ?></span>
                    <div class="bar-track">
                        <div class="bar-fill" style="width: <?= $pct ?>%;"></div>
                    </div>
                    <span class="bar-value">&#2547;<?= number_format((float) $row['revenue'], 2) ?> (<?= (int) $row['units'] ?> units)</span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<section class="panel">
    <div class="panel-header"><h2>Orders by Status (in range)</h2></div>
    <div class="status-pills">
        <?php foreach (['pending', 'processing', 'shipped', 'delivered', 'cancelled'] as $s): ?>
            <span class="badge badge-<?= $s ?>"><?= ucfirst($s) ?>: <?= (int) ($byStatus[$s] ?? 0) ?></span>
        <?php endforeach; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
