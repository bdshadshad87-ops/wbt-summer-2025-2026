<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_discount') {
    if (!csrf_check()) {
        flash_set('error', 'Invalid form submission. Please try again.');
        header('Location: discount.php');
        exit;
    }

    $productId = (int) ($_POST['product_id'] ?? 0);
    $rawPercent = trim($_POST['discount_percent'] ?? '');
    $startDate = trim($_POST['start_date'] ?? '');
    $endDate   = trim($_POST['end_date'] ?? '');

    $errors = [];

    if ($productId <= 0) {
        $errors[] = 'Invalid product.';
    }

    if ($rawPercent === '' || !is_numeric($rawPercent)) {
        $errors[] = 'Discount must be a number.';
    } elseif ((float) $rawPercent < 0 || (float) $rawPercent > 90) {
        $errors[] = 'Discount must be between 0 and 90 percent.';
    }

    if (!valid_date($startDate)) {
        $errors[] = 'Start date must be a real date in YYYY-MM-DD format.';
    }

    if (!valid_date($endDate)) {
        $errors[] = 'End date must be a real date in YYYY-MM-DD format.';
    }

    if (!$errors && $endDate < $startDate) {
        $errors[] = 'End date cannot be earlier than the start date.';
    }

    if (!$errors) {
        $own = db_query($conn, 'SELECT product_id FROM products WHERE product_id = ? AND seller_id = ?', 'ii', [$productId, $sellerId]);
        if (!db_fetch_one($own)) {
            $errors[] = 'You do not have permission to set a discount on that product.';
        }
    }

    if ($errors) {
        flash_set('error', $errors[0]);
        header('Location: discount.php');
        exit;
    }

    $percent = (float) $rawPercent;

    $existing = db_query($conn, 'SELECT discount_id FROM discounts WHERE product_id = ?', 'i', [$productId]);
    $existingId = db_fetch_column($existing);

    if ($existingId) {
        db_query(
            $conn,
            'UPDATE discounts SET discount_percent = ?, start_date = ?, end_date = ?, is_active = 1
             WHERE discount_id = ? AND seller_id = ?',
            'dssii',
            [$percent, $startDate, $endDate, (int) $existingId, $sellerId]
        );
    } else {
        db_query(
            $conn,
            'INSERT INTO discounts (product_id, seller_id, discount_percent, start_date, end_date, is_active)
             VALUES (?, ?, ?, ?, ?, 1)',
            'iidss',
            [$productId, $sellerId, $percent, $startDate, $endDate]
        );
    }

    flash_set('success', 'Discount saved.');
    header('Location: discount.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'deactivate_discount') {
    if (!csrf_check()) {
        flash_set('error', 'Invalid form submission. Please try again.');
        header('Location: discount.php');
        exit;
    }

    $discountId = (int) ($_POST['discount_id'] ?? 0);

    if ($discountId <= 0) {
        flash_set('error', 'Invalid discount.');
        header('Location: discount.php');
        exit;
    }

    $upd = db_query($conn, 'UPDATE discounts SET is_active = 0 WHERE discount_id = ? AND seller_id = ?', 'ii', [$discountId, $sellerId]);

    if ($upd->affected_rows === 0) {
        flash_set('error', 'You do not have permission to change that discount.');
    } else {
        flash_set('success', 'Discount deactivated.');
    }

    header('Location: discount.php');
    exit;
}

$rows = db_fetch_all(db_query(
    $conn,
    'SELECT p.product_id, p.name, p.price, d.discount_id, d.discount_percent,
            d.start_date, d.end_date, d.is_active
     FROM products p
     LEFT JOIN discounts d ON d.product_id = p.product_id
     WHERE p.seller_id = ?
     ORDER BY p.name ASC',
    'i',
    [$sellerId]
));

$pageTitle = 'Discounts';
require_once __DIR__ . '/../includes/header.php';
?>

<?php flash_render(); ?>

<section class="panel">
    <div class="panel-header">
        <h2>Manage Product Discounts</h2>
        <span class="panel-subtitle">Discount range 0&ndash;90%. Dates must be real calendar dates.</span>
    </div>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Discount %</th>
                    <th>Valid From</th>
                    <th>Valid To</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$rows): ?>
                <tr><td colspan="7" class="empty-row">No products found.</td></tr>
            <?php else: foreach ($rows as $r):
                $formId = 'discForm' . (int) $r['product_id'];
                $today  = date('Y-m-d');
                $isLive = $r['is_active'] && $r['start_date'] <= $today && $r['end_date'] >= $today;
            ?>
                <tr>
                    <td><?= htmlspecialchars($r['name']) ?></td>
                    <td>&#2547;<?= number_format((float) $r['price'], 2) ?></td>
                    <td><input type="number" step="0.01" min="0" max="90" name="discount_percent"
                               value="<?= htmlspecialchars($r['discount_percent'] ?? '0') ?>"
                               class="qty-input" form="<?= $formId ?>"></td>
                    <td><input type="date" name="start_date" value="<?= htmlspecialchars($r['start_date'] ?? $today) ?>" form="<?= $formId ?>"></td>
                    <td><input type="date" name="end_date" value="<?= htmlspecialchars($r['end_date'] ?? $today) ?>" form="<?= $formId ?>"></td>
                    <td>
                        <?php if ($isLive): ?>
                            <span class="badge badge-ok">Active</span>
                        <?php elseif ($r['discount_id']): ?>
                            <span class="badge badge-muted">Inactive</span>
                        <?php else: ?>
                            <span class="badge badge-muted">None</span>
                        <?php endif; ?>
                    </td>
                    <td class="action-cell">
                        <form id="<?= $formId ?>" method="post" action="discount.php">
                            <input type="hidden" name="action" value="save_discount">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
                            <input type="hidden" name="product_id" value="<?= (int) $r['product_id'] ?>">
                        </form>
                        <button type="submit" form="<?= $formId ?>" class="btn btn-sm">Save</button>
                        <?php if ($r['discount_id'] && $r['is_active']): ?>
                            <form method="post" action="discount.php" class="inline-form">
                                <input type="hidden" name="action" value="deactivate_discount">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
                                <input type="hidden" name="discount_id" value="<?= (int) $r['discount_id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger">Deactivate</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
