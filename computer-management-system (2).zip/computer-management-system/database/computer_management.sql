SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE DATABASE IF NOT EXISTS computer_management
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE computer_management;

CREATE TABLE IF NOT EXISTS users (
    user_id     INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)        NOT NULL,
    email       VARCHAR(150)        NOT NULL UNIQUE,
    password    VARCHAR(255)        NOT NULL,
    phone       VARCHAR(20)         DEFAULT NULL,
    role        ENUM('customer','seller','vendor','admin') NOT NULL,
    status      ENUM('active','blocked') NOT NULL DEFAULT 'active',
    created_at  TIMESTAMP           NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
    product_id      INT AUTO_INCREMENT PRIMARY KEY,
    seller_id       INT             NOT NULL,
    vendor_id       INT             DEFAULT NULL,
    name            VARCHAR(150)    NOT NULL,
    description     TEXT            DEFAULT NULL,
    category        VARCHAR(80)     DEFAULT NULL,
    brand           VARCHAR(80)     DEFAULT NULL,
    price           DECIMAL(10,2)   NOT NULL,
    wholesale_price DECIMAL(10,2)   DEFAULT NULL,
    image           VARCHAR(255)    DEFAULT NULL,
    is_damaged      TINYINT(1)      NOT NULL DEFAULT 0,
    created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP
                                     ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_products_seller FOREIGN KEY (seller_id) REFERENCES users(user_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_products_vendor FOREIGN KEY (vendor_id) REFERENCES users(user_id)
        ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock (
    stock_id            INT AUTO_INCREMENT PRIMARY KEY,
    product_id          INT UNIQUE      NOT NULL,
    quantity            INT             NOT NULL DEFAULT 0,
    low_stock_threshold INT             NOT NULL DEFAULT 5,
    updated_at          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_stock_product FOREIGN KEY (product_id) REFERENCES products(product_id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS discounts (
    discount_id      INT AUTO_INCREMENT PRIMARY KEY,
    product_id       INT             NOT NULL,
    seller_id        INT             NOT NULL,
    discount_percent DECIMAL(5,2)    NOT NULL,
    start_date       DATE            NOT NULL,
    end_date         DATE            NOT NULL,
    is_active        TINYINT(1)      NOT NULL DEFAULT 1,
    created_at       TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_discount_product FOREIGN KEY (product_id) REFERENCES products(product_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_discount_seller FOREIGN KEY (seller_id) REFERENCES users(user_id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
    order_id          INT AUTO_INCREMENT PRIMARY KEY,
    customer_id        INT             NOT NULL,
    order_date         TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status              ENUM('pending','processing','shipped','delivered','cancelled')
                         NOT NULL DEFAULT 'pending',
    delivery_address    VARCHAR(255)    DEFAULT NULL,
    payment_method       VARCHAR(50)     DEFAULT NULL,
    total_amount        DECIMAL(10,2)   NOT NULL DEFAULT 0,
    CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES users(user_id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
    order_item_id  INT AUTO_INCREMENT PRIMARY KEY,
    order_id       INT             NOT NULL,
    product_id     INT             NOT NULL,
    seller_id      INT             NOT NULL,
    quantity       INT             NOT NULL,
    unit_price     DECIMAL(10,2)   NOT NULL,
    subtotal       DECIMAL(10,2)   NOT NULL,
    CONSTRAINT fk_items_order   FOREIGN KEY (order_id)   REFERENCES orders(order_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_items_product FOREIGN KEY (product_id) REFERENCES products(product_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_items_seller  FOREIGN KEY (seller_id)  REFERENCES users(user_id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO users (name, email, password, phone, role) VALUES
('Rafiq Seller', 'seller@shop.test', '$2y$12$AAcbo7MhElAG0YamFG016ORjeMi4U.uRN3Ckj9QXwrdspzxsPorre', '01710000001', 'seller'),
('Karim Vendor', 'vendor@shop.test', '$2y$12$AAcbo7MhElAG0YamFG016ORjeMi4U.uRN3Ckj9QXwrdspzxsPorre', '01710000002', 'vendor'),
('Nusrat Customer', 'customer@shop.test', '$2y$12$AAcbo7MhElAG0YamFG016ORjeMi4U.uRN3Ckj9QXwrdspzxsPorre', '01710000003', 'customer'),
('Site Admin', 'admin@shop.test', '$2y$12$AAcbo7MhElAG0YamFG016ORjeMi4U.uRN3Ckj9QXwrdspzxsPorre', '01710000004', 'admin');

INSERT INTO products (seller_id, vendor_id, name, description, category, brand, price, wholesale_price) VALUES
(1, 2, 'Intel Core i5-13400F', '10-core desktop processor', 'CPU', 'Intel', 18500.00, 15800.00),
(1, 2, 'NVIDIA RTX 4060 8GB', 'Mid-range gaming GPU', 'GPU', 'NVIDIA', 42000.00, 37500.00),
(1, 2, 'Corsair Vengeance 16GB DDR4', '3200MHz desktop RAM kit', 'RAM', 'Corsair', 5200.00, 4400.00),
(1, 2, 'Samsung 980 1TB NVMe SSD', 'PCIe Gen3 NVMe SSD', 'Storage', 'Samsung', 8900.00, 7600.00),
(1, 2, 'Cooler Master MWE 650W', '80+ Bronze power supply', 'PSU', 'Cooler Master', 6200.00, 5300.00);

INSERT INTO stock (product_id, quantity, low_stock_threshold) VALUES
(1, 12, 5),
(2, 3, 5),
(3, 25, 8),
(4, 4, 6),
(5, 15, 5);

INSERT INTO discounts (product_id, seller_id, discount_percent, start_date, end_date, is_active) VALUES
(2, 1, 10.00, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 1);

INSERT INTO orders (customer_id, status, delivery_address, payment_method, total_amount) VALUES
(3, 'pending',    'House 12, Road 5, Dhanmondi, Dhaka', 'Cash on Delivery', 60500.00),
(3, 'processing', 'House 12, Road 5, Dhanmondi, Dhaka', 'bKash',            14100.00),
(3, 'delivered',  'House 12, Road 5, Dhanmondi, Dhaka', 'Card',              6200.00);

INSERT INTO order_items (order_id, product_id, seller_id, quantity, unit_price, subtotal) VALUES
(1, 1, 1, 1, 18500.00, 18500.00),
(1, 2, 1, 1, 42000.00, 42000.00),
(2, 3, 1, 2, 5200.00, 10400.00),
(2, 4, 1, 1,  8900.00, 8900.00),
(3, 5, 1, 1,  6200.00,  6200.00);
