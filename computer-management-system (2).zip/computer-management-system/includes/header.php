<?php
$pageTitle = $pageTitle ?? 'Seller Panel';
$currentPage = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?> | Computer Shop Management System</title>
<link rel="stylesheet" href="../css/seller.css">
</head>
<body>
<div class="app-shell">

    <aside class="sidebar">
        <div class="sidebar-brand">
            <span class="brand-icon">&#128421;</span>
            <span class="brand-text">Seller Panel</span>
        </div>
        <nav class="sidebar-nav">
            <a href="dashboard.php" class="<?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
                <span class="icon">&#128202;</span> Dashboard
            </a>
            <a href="products.php" class="<?= in_array($currentPage, ['products.php', 'product_form.php'], true) ? 'active' : '' ?>">
                <span class="icon">&#128187;</span> Products
            </a>
            <a href="stock.php" class="<?= $currentPage === 'stock.php' ? 'active' : '' ?>">
                <span class="icon">&#128230;</span> Stock
            </a>
            <a href="discount.php" class="<?= $currentPage === 'discount.php' ? 'active' : '' ?>">
                <span class="icon">&#127991;</span> Discounts
            </a>
            <a href="orders.php" class="<?= in_array($currentPage, ['orders.php', 'update_order.php'], true) ? 'active' : '' ?>">
                <span class="icon">&#128203;</span> Orders
            </a>
            <a href="sales_summary.php" class="<?= $currentPage === 'sales_summary.php' ? 'active' : '' ?>">
                <span class="icon">&#128176;</span> Sales Summary
            </a>
        </nav>
        <div class="sidebar-footer">
            <a href="logout.php" class="logout-link">&#8592; Logout</a>
        </div>
    </aside>

    <div class="main-area">
        <header class="topbar">
            <h1 class="page-title"><?= htmlspecialchars($pageTitle) ?></h1>
            <div class="topbar-right">
                <div class="notification-wrap">
                    <button id="notifBell" class="notif-bell" type="button" aria-label="Low stock notifications">
                        &#128276;
                        <span id="notifCount" class="notif-count" hidden>0</span>
                    </button>
                    <div id="notifDropdown" class="notif-dropdown" hidden>
                        <div class="notif-dropdown-title">Low stock alerts</div>
                        <div id="notifList" class="notif-list">
                            <p class="notif-empty">Loading...</p>
                        </div>
                    </div>
                </div>
                <div class="seller-chip">
                    <span class="seller-avatar"><?= strtoupper(substr($sellerName, 0, 1)) ?></span>
                    <span class="seller-name"><?= htmlspecialchars($sellerName) ?></span>
                </div>
            </div>
        </header>
        <main class="content">
