<?php
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']),
    ]);
    session_start();
}

require_once __DIR__ . '/../config/database.php';

if (empty($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'seller') {
    header('Location: ../login.php');
    exit;
}

$IDLE_TIMEOUT = 1800;

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $IDLE_TIMEOUT) {
    $_SESSION = [];
    session_destroy();
    header('Location: ../login.php?msg=' . urlencode('Session expired. Please sign in again.'));
    exit;
}
$_SESSION['last_activity'] = time();

$sellerId   = (int) $_SESSION['user_id'];
$sellerName = $_SESSION['name'] ?? 'Seller';

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_check(): bool
{
    return isset($_POST['csrf_token'], $_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']);
}

function text_length(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

function valid_date(string $date): bool
{
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m)) {
        return false;
    }
    return checkdate((int) $m[2], (int) $m[3], (int) $m[1]);
}
