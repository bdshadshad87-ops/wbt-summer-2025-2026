        </main>
    </div>
</div>
<script src="../js/seller.js"></script>
</body>
</html>
